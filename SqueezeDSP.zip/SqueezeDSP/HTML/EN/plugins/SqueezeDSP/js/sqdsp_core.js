/*---------------------------------------------------
Core UI Controls and Display Logic
-----------------------------------------------------*/

function logParentTheme() {
    const body = document.body;
    const textColor = getComputedStyle(body).color;
    
    console.log('=== THEME DETECTION LOG ===');
    console.log('Body classes:', body.className);
    console.log('Body computed color:', textColor);
    
    // Simple rule: if text color is light, we're in dark mode. If dark, we're in light mode.
    const rgb = textColor.match(/\d+/g);
    let isDark = false;
    
    if (rgb && rgb.length >= 3) {
        const [r, g, b] = rgb;
        const brightness = (r * 299 + g * 587 + b * 114) / 1000;
        isDark = brightness > 128; // Light text = dark theme
    }
    
    console.log('Decision: Using', isDark ? 'DARK' : 'LIGHT', 'theme based on text color');
    return isDark ? 'dark' : 'light';
}


function refreshPresetList() {
    SqueezeDSPGetList(function(data) {
        LocalBuildList('Preset', data);
    });
}



function LocalBuildLists(data) {
    LocalBuildList('FIRWavFile', data);
    LocalBuildList('Preset', data);
}

function LocalBuildList(listType, data) {
    var select = document.getElementById("sel_" + listType);
    select.options.length = 1;
    
    var loop = data.result[listType + "_loop"];
    if (typeof loop == "object") {
        for (var j = 0; j < loop.length; j++) {
            var fullPath = loop[j][0];
            var fileName = fullPath.split(/[\\/]/).pop();
            
            var el = document.createElement("option");
            el.value = fullPath;
            el.textContent = fileName;
            el.dataset.fullPath = fullPath;
            
            select.appendChild(el);
        }
    }
}


function LocalUpdateSettings() {
    rebuildPEQUI('peqContainer');
    LocalDisplayVals();    
    
    myRadio = LocalSetupToggle('DSP', SqueezeDSPData.Client.Bypass, true);
    ToggleControl(myRadio, 'DSP_container', true);
    ToggleControl(myRadio, 'DSP_container_signal', true);
    LocalSetupOutput();
    LocalSetupUpsample();
    LocalSetupDSD();

    myRadio = LocalSetupToggle('Loudness', replaceNull(SqueezeDSPData.Client.Loudness.enabled,0));
    ToggleControl(myRadio, 'control_Loudness', false); 
	myRadio = LocalSetupToggle('ReplayGain', replaceNull(SqueezeDSPData.Client.ReplayGain && SqueezeDSPData.Client.ReplayGain.enabled, 0));
    updateReplayGainToggle();
    
    reStyleElement('btn_Apply', 'button-amber', 'button-blue');
    ListenForSlide();
	GetLogSummary();
}

function LocalDisplayVals() {
    if (!SqueezeDSPData.Client) SqueezeDSPData.Client = {};
    DisplayVal('Delay.delay', replaceNull(SqueezeDSPData.Client.Delay.delay, 0));
    DisplayVal('Width', replaceNull(SqueezeDSPData.Client.Width, 0));
    DisplayVal('Balance', replaceNull(SqueezeDSPData.Client.Balance, 0));
    DisplayVal('Preamp', replaceNull(SqueezeDSPData.Client.Preamp, 0));
    DisplayVal('Loudness.listening_level', replaceNull(SqueezeDSPData.Client.Loudness.listening_level,85));
	// Replay Gain — use specific defaults if not set
	const rgFixed = (SqueezeDSPData.Client.ReplayGain && SqueezeDSPData.Client.ReplayGain.fixed_gain != null)
    ? SqueezeDSPData.Client.ReplayGain.fixed_gain
    : -6.0;
	document.getElementById('val_ReplayGain.fixed_gain').value = rgFixed;
	// Replay Gain Spotify gain — use specific default if not set ( spotify internal replaygain is targetting -14 LUFS, which is about -4 dB compared to the common -11 LUFS target)
	const rgSpotify = (SqueezeDSPData.Client.ReplayGain && SqueezeDSPData.Client.ReplayGain.spotify_gain != null)
    ? SqueezeDSPData.Client.ReplayGain.spotify_gain
    : -4.0;
	document.getElementById('val_ReplayGain.spotify_gain').value = rgSpotify;

	DisplayVal('FIRStrength', replaceNull(SqueezeDSPData.Client.FIRStrength, 100));

	// Crossfeed — restore radio state
	const cfVal = replaceNull(SqueezeDSPData.Client.Crossfeed, 'off');
	const cfRadio = document.querySelector(`#crossfeed-selector input[value="${cfVal}"]`);
	if (cfRadio) cfRadio.checked = true;


    const presetPath = SqueezeDSPData.Client.Preset || 'none';
  
    document.getElementById('edt_NewPreset').value = getBaseFilename(presetPath);
    
    const firPath = SqueezeDSPData.Client.FIRWavFile || 'none';
    highlightMatchingOption('sel_FIRWavFile', firPath);
    
  
    document.getElementById('ClientName').value = SqueezeDSPData.ClientName;
}

function DisplayVal(ElName, MyVal) {
    try {
        document.getElementById(ElName).value = MyVal;
        document.getElementById('val_' + ElName).value = MyVal;
    } catch {
        DisplayAlert(ElName, "Function DisplayVal failing for:");
    }
}

function LocalSetupToggle(myControl, newValue, InvertToggle = false) {
    myCheck = document.getElementById(myControl);
    myCheck.value = newValue;
    
    if (myCheck.value == 1) {
        if (!InvertToggle) myCheck.checked = true;
        else myCheck.checked = false;
    }
    if (myCheck.value == 0) {
        if (InvertToggle) myCheck.checked = true;
        else myCheck.checked = false;
    }
    return myCheck;
}

// Output format: FLAC 24-bit (the default), or PCM as 24-bit WAV with its header, which only
// a player that reads the header can take (a squeezelite started with -W). A player that
// cannot take 24-bit FLAC gets no DSP at all. readclientSettings reports both (dsp_ok,
// wav_ok); the server applies the same rule whatever the page sends.
function LocalSetupOutput() {
    const can = (typeof SqueezeDSPPlayer === 'object' && SqueezeDSPPlayer) ? SqueezeDSPPlayer : { dspOk: true, wavOk: false };
    const outVal = replaceNull(SqueezeDSPData.Client.OutputFormat, 'FLAC');
    const flac = document.querySelector('#output-selector input[value="FLAC"]');
    const pcm  = document.querySelector('#output-selector input[value="PCM"]');
    const note = document.getElementById('note_OutputFormat');
    const dsp  = document.getElementById('DSP');

    if (pcm) {
        pcm.disabled = !can.wavOk;
        pcm.checked = (outVal === 'PCM');
    }
    if (flac) flac.checked = (outVal !== 'PCM');
    if (dsp) dsp.disabled = !can.dspOk;

    let msg = '';
    if (!can.dspOk) msg = document.getElementById('NoDSPBelowFLAC_Help').value;
    else if (can.outReduced) {
        // a reduced stream overrides the output chosen here while it is due (Bitrate Limiting, or the app's own list)
        const names = { MP3: 'MP3 (320 kbps)', OPS: 'Opus (256 kbps)', OGG: 'Ogg Vorbis (quality 10)' };
        const limit = can.outReduced === 'MP3' && can.outKbps;
        const el = document.getElementById(limit ? 'ReducedLimit_Help' : 'ReducedApp_Help');
        msg = el ? el.value.replace('%s', limit ? can.outKbps : (names[can.outReduced] || can.outReduced)) : '';
    }
    else if (!can.wavOk) msg = document.getElementById('PCMNeedsHeader_Help').value;
    if (note) note.textContent = msg;
    const box = document.getElementById('body_output_note');
    if (box) box.style.display = msg ? '' : 'none';
}

// Upsample (Upsample.pm), off by default; when on, the filter options show. readclientSettings
// says whether this player can upsample (up_ok: an ffmpeg with soxr, a known max), why not, and
// its two targets. A player that cannot shows Off whatever is stored, and the server writes no
// upsample rules for it, whatever the page sends. Intermediate and minimum phase need sox (up_sox);
// without it the server writes linear, and the page shows linear. The target rate is each track's own
// family (up_targets) or one fixed rate, the player's top (up_fixed). A max rate caps both, up to the
// player's top rate for its output (up_limits: FLAC out, WAV out); the page names the rates from it as the
// server does (Upsample::targets), so a change of output or max rate shows before the server is asked.
const UPSAMPLE_MAX_RATES = [768000, 384000, 192000, 96000];
// the passband (Upsample.pm PASSBAND_FAMILY, PASSBAND_FIXED): per family 99% by default; a fixed target 95% by default
// and at most that
const UPSAMPLE_PASSBAND_FAMILY = 0.99, UPSAMPLE_PASSBAND_FIXED = 0.95;
function upsampleRates(limit, max) {
    const ceil = (max && (!limit || max < limit)) ? max : limit;
    if (!ceil) return null;
    let f44 = 44100, f48 = 48000;
    while (f44 * 2 <= ceil) f44 *= 2;
    while (f48 * 2 <= ceil) f48 *= 2;
    if (f48 > ceil) f48 = f44;
    return { f44: f44, f48: f48, top: Math.max(f44, f48) };
}
function LocalSetupUpsample() {
    const can = (typeof SqueezeDSPPlayer === 'object' && SqueezeDSPPlayer) ? SqueezeDSPPlayer : { upOk: false, upWhy: '', upTargets: '', upFixed: '', upLimits: '', upFfmpeg: '', upSox: '' };
    const c = SqueezeDSPData.Client;
    const on = (replaceNull(c.Upsample, 'off') === 'on') && can.upOk;
    const sw    = document.getElementById('chk_Upsample');
    const opts  = document.getElementById('upsample-options');
    const note  = document.getElementById('note_Upsample');

    if (sw) {
        sw.disabled = !can.upOk;
        sw.checked = on;
        sw.value = on ? 'on' : 'off';
    }

    // the target the server writes: one it knows, else each track's own family
    const targets = ['family', 'fixed'];
    let target = String(replaceNull(c.UpsampleTarget, 'family')).toLowerCase();
    if (!targets.includes(target)) target = 'family';
    targets.forEach(t => {
        const el = document.querySelector(`#upsample-target-selector input[value="${t}"]`);
        if (el) el.checked = (t === target);
    });

    // the max rate the server writes: one it knows, at or below the player's top rate for its output;
    // above it, or unknown, the player's own (0)
    const limits = String(can.upLimits || '').split(',').map(Number);
    const pcm = replaceNull(c.OutputFormat, 'FLAC') === 'PCM' && can.wavOk;
    const limit = (pcm ? limits[1] : limits[0]) || 0;
    let max = Number(replaceNull(c.UpsampleMax, 0));
    if (!UPSAMPLE_MAX_RATES.includes(max) || (limit && max > limit)) max = 0;
    document.querySelectorAll('#upsample-max-selector input[type="radio"]').forEach(el => {
        const v = Number(el.value);
        el.disabled = v > 0 && limit > 0 && v > limit;
        el.checked = (v === max);
    });

    // the phase the server writes: one it knows, and linear unless there is a sox
    const phases = ['linear', 'intermediate', 'minimum'];
    let phase = String(replaceNull(c.UpsamplePhase, 'linear')).toLowerCase();
    if (!phases.includes(phase) || !can.upSox) phase = 'linear';
    phases.forEach(p => {
        const el = document.querySelector(`#upsample-phase-selector input[value="${p}"]`);
        if (!el) return;
        el.disabled = (p !== 'linear') && !can.upSox;
        el.checked = (p === phase);
    });

    // the server's own defaults stand in for a value the page has no option for
    setChoice('upsample-precision-selector', replaceNull(c.UpsamplePrecision, 28), 28);
    // the passband: the target's default stands in for none; a fixed target offers 95% and lower, and shows a higher
    // one stored at the 95% it plays at (kept as stored, so per family gets it back)
    // (not replaceNull: Auto is 0, which it would take for none)
    const pbDefault = target === 'fixed' ? UPSAMPLE_PASSBAND_FIXED : UPSAMPLE_PASSBAND_FAMILY;
    const pbStored = c.UpsamplePassband;
    let pb = (pbStored === undefined || pbStored === null || pbStored === '') ? pbDefault : Number(pbStored);
    if (target === 'fixed' && pb > UPSAMPLE_PASSBAND_FIXED) pb = UPSAMPLE_PASSBAND_FIXED;
    document.querySelectorAll('#upsample-passband-selector input[type="radio"]').forEach(el => {
        el.disabled = target === 'fixed' && Number(el.value) > UPSAMPLE_PASSBAND_FIXED;
    });
    setChoice('upsample-passband-selector', pb, pbDefault);
    const steep = document.getElementById('chk_UpsampleSteep');
    if (steep) {
        steep.checked = Number(replaceNull(c.UpsampleSteep, 0)) === 1;
        steep.value = steep.checked ? 1 : 0;
    }
    if (opts) opts.style.display = on ? '' : 'none';

    let msg = '';
    if (!can.upOk) {
        const ids = { nosoxr: 'UpsampleNoSoxr_Help', noffmpeg: 'UpsampleNoFfmpeg_Help', nomax: 'UpsampleNoMax_Help', hook: 'UpsampleNoHook_Help',
                      reduced: 'UpsampleNoReduced_Help' };
        const el = document.getElementById(ids[can.upWhy] || 'UpsampleNoFfmpeg_Help');
        msg = el ? el.value : '';
        if (can.upWhy === 'nosoxr' && can.upFfmpeg) msg += ' ' + can.upFfmpeg;
    } else if (on && can.upTargets) {
        // from the limit and max rate when the server sent the limits, else as the server last named them
        const r = upsampleRates(limit, max);
        const fixed = target === 'fixed' && (r || can.upFixed);
        const el = document.getElementById(fixed ? 'UpsampleFixed_Help' : 'UpsampleTargets_Help');
        const khz = x => (Number(x) / 1000) + ' kHz';
        const rates = fixed ? khz(r ? r.top : can.upFixed)
                            : (r ? [r.f44, r.f48] : can.upTargets.split(',')).map(khz).join(' / ');
        msg = (el ? el.value + ' ' : '') + rates;
        if (!can.upSox) {
            const ns = document.getElementById('UpsampleNoSox_Help');
            if (ns) msg += ' ' + ns.value;
        }
    }
    if (note) {
        note.textContent = msg;
        note.style.display = msg ? '' : 'none';
    }
}

// check the button of a choice group whose value is the stored one, compared as numbers ('0.90' is 0.9);
// none matching, the fallback's
// DSD: how our engine decodes a DSF (ledger OUR OWN DSD DECODER), the player's DSDCutoff and DSDGain, shown as the engine
// takes them (LyrionDSPSettings buildConfig): unset, unreadable or out of range, its default, 30 kHz and 0 dB
function LocalSetupDSD() {
    const c = SqueezeDSPData.Client;
    const cs = c.DSDCutoff;   // (not replaceNull: None is 0, which it would take for none)
    const cut = (cs === undefined || cs === null || cs === '') ? 30000 : Number(cs);
    const gain = Number(replaceNull(c.DSDGain, 0));
    setChoice('dsd-cutoff-selector', (cut === 0 || (cut > 20000 && cut <= 60000)) ? cut : 30000, 30000);
    setChoice('dsd-gain-selector', (gain >= -24 && gain <= 12) ? gain : 0, 0);
}

function setChoice(groupId, value, fallback) {
    const inputs = document.querySelectorAll('#' + groupId + ' input[type="radio"]');
    const same = (a, b) => Number(a) === Number(b) && String(a).trim() !== '' && String(b).trim() !== '';
    const want = Array.prototype.some.call(inputs, i => same(i.value, value)) ? value : fallback;
    inputs.forEach(i => { i.checked = same(i.value, want); });
}

function ToggleControl(myElement, myControltoToggle, InvertToggle = false) {
    var myValue = myElement.value;
    var element = document.getElementById(myControltoToggle);

    if (InvertToggle) {
        if (myValue == 1) {
            element.style.display = 'none';
            
        } else {
            element.style.display = ''; // or 'block' depending on your layout
            
        }
    } else {
        if (myValue == 0) {
            element.style.display = 'none';
            
        } else {
            element.style.display = '';
            
        }
    }
}

function updateLoudnessToggle() {
    const loudnessEnabled = SqueezeDSPData.Client.Loudness && SqueezeDSPData.Client.Loudness.enabled == 1;
    const loudnessControl = document.getElementById('control_Loudness');
    
    if (loudnessControl) {
        loudnessControl.style.display = loudnessEnabled ? '' : 'none';
    }
    
    // Update graph visibility and content
    updateGraphVisibility();
    updatePEQGraph();
}

function updateReplayGainToggle() {
    const enabled = SqueezeDSPData.Client.ReplayGain && SqueezeDSPData.Client.ReplayGain.enabled == 1;
    const fixedGainInput  = document.getElementById('val_ReplayGain.fixed_gain');
    const spotifyGainInput = document.getElementById('val_ReplayGain.spotify_gain');
    const spotifyRow      = document.getElementById('control_ReplayGain.spotify_gain');
    const modeLabels      = document.getElementById('replaygain-mode-labels');
    const trackOnly       = document.getElementById('ReplayGainTrackOnly');
    const albumOnly       = document.getElementById('ReplayGainAlbumOnly');

    if (fixedGainInput) {
        fixedGainInput.disabled    = !enabled;
        fixedGainInput.style.opacity = enabled ? '1' : '0.4';
    }
    if (spotifyGainInput) {
        spotifyGainInput.disabled    = !enabled;
        spotifyGainInput.style.opacity = enabled ? '1' : '0.4';
    }
    if (spotifyRow) {
        spotifyRow.style.display = enabled ? '' : 'none';
    }

    // Show mode checkboxes only when ReplayGain is enabled
    if (modeLabels) {
        modeLabels.style.display = enabled ? '' : 'none';
    }

    // Reflect current mode onto checkboxes
    if (trackOnly && albumOnly) {
        const mode = SqueezeDSPData.Client.ReplayGain.mode || 3;
        trackOnly.checked = (mode === 1);
        albumOnly.checked = (mode === 2);
    }
}

// Called when either mode checkbox changes.
// The two are mutually exclusive — checking one clears the other.
// If both are unchecked the mode falls back to smart gain (3).
function onReplayGainModeChange(which, checkbox) {
    const trackOnly = document.getElementById('ReplayGainTrackOnly');
    const albumOnly = document.getElementById('ReplayGainAlbumOnly');

    if (which === 'track') {
        if (checkbox.checked) albumOnly.checked = false;
    } else {
        if (checkbox.checked) trackOnly.checked = false;
    }

    const mode = trackOnly.checked ? 1 : albumOnly.checked ? 2 : 3;
    SqueezeDSPData.Client.ReplayGain.mode = mode;
    NewFieldValue('ReplayGain.mode', { value: mode }, false);
}


function reStyleElement(ElementId, fromStyle, toStyle) {
    const myElement = document.getElementById(ElementId);
    if (myElement) {
        myElement.classList.remove(fromStyle);
        myElement.classList.add(toStyle);
    } else {
        console.warn(`Element with ID '${ElementId}' not found.`);
    }
}

function HideAlert() {
    myMessage.className = "bubble";
    myMessage.innerText = '';
}

function DisplayAlert(FieldName, Message, Duration = 2000) {
    myMessage.className = "localAlert";
    myMessage.innerText = Message + ' ' + FieldName + " ...";
    setTimeout(function() { HideAlert(); }, Duration);    
}

function SetNewPreset(myEl) {
    var val = myEl.value;
    //Remove callback, it was originally to check that everything had been saved
    SqueezeDSPSavePreset(val);    
    DisplayAlert('Preset', 'Saving to ' + val);
}

function GetLogSummary() {
    SqueezeDSPLogSummary(LocalDisplayLogSummary);
}

function LocalDisplayLogSummary(logData) {
    let myHTML = '';
    const tracklimit = 10;
    let enabled = SqueezeDSPData.Client.ReplayGain && SqueezeDSPData.Client.ReplayGain.enabled == 1;
	if (enabled == undefined) enabled = 0;
    try {
        for (let i = 1; i <= tracklimit; i++) {
            const peakdBfs = logData.result ? logData.result['peakdBfs_' + i] : undefined;
            let peakStyle = 'peak peak-unknown';

            // Skip if peak is not a number
			/*
            if (typeof peakdBfs !== 'number') {
                peakStyle = 'peak peak-unknown';
			}*/
           if (enabled == 1) {
                if (peakdBfs < -12) peakStyle = 'peak peak-toolow';
                else if (peakdBfs < -8) peakStyle = 'peak peak-bitlow'; // fixed name
                else if (peakdBfs < -3) peakStyle = 'peak peak-ok';
                else if (peakdBfs < 0) peakStyle = 'peak peak-high';
				else if (peakdBfs >= 0) peakStyle = 'peak peak-clipping';
                else peakStyle = 'peak peak peak-unknown';
            } else {
                if (peakdBfs < -5) peakStyle = 'peak peak-toolow';
                else if (peakdBfs < -1) peakStyle = 'peak peak-ok';
                else if (peakdBfs <= 0.1) peakStyle = 'peak peak-high';
                else if (peakdBfs >= 0) peakStyle = 'peak peak-clipping';
				else peakStyle = 'peak peak peak-unknown';
                // No final else – unknown stays unknown*/
            }

            // Build tooltip with safe fallbacks
            const safeValue = (key) => (logData.result && logData.result[key] != null) ? logData.result[key] : '—';
				const tooltipContent = `
					<div class="tooltip-row">
						<div class="tooltip-label">Playerid:</div>
						<div class="tooltip-value">${safeValue('playerid_' + i)}</div>
					</div>
					<div class="tooltip-row">
						<div class="tooltip-label">Start Date:</div>
						<div class="tooltip-value">${safeValue('date_' + i)}</div>
					</div>
					<div class="tooltip-row">
						<div class="tooltip-label">Start Time:</div>
						<div class="tooltip-value">${safeValue('time_' + i)}</div>
					</div>
					<div class="tooltip-row">
						<div class="tooltip-label">Preamp Gain:</div>
						<div class="tooltip-value">${safeValue('preamp_' + i)}</div>
					</div>
					<div class="tooltip-row">
						<div class="tooltip-label">Internal Gain:</div>
						<div class="tooltip-value">${safeValue('internalgain_' + i)}</div>
					</div>
					<div class="tooltip-row">
						<div class="tooltip-label">Sample Rate:</div>
						<div class="tooltip-value">${safeValue('outputrate_' + i)}</div>
					</div>
					<div class="tooltip-row">
						<div class="tooltip-label">Peak Level:</div>
						<div class="tooltip-value">${peakdBfs}</div>
					</div>
					<div class="tooltip-row">
						<div class="tooltip-label">Input Peak:</div>
						<div class="tooltip-value">${safeValue('inputpeak_' + i)}</div>
					</div>
				`;

            myHTML += `
                <div class="led-container">
                    <div class="${peakStyle}"></div>
                    <div class="tooltiptext">
                        ${tooltipContent}
                    </div>
                </div>
            `;
        }
    } catch (error) {
        console.error("LocalDisplayLogSummary error:", error);
        DisplayAlert("LocalDisplayLogSummary", "Error building log summary", 3000);
    }

    document.getElementById('logSummary').innerHTML = myHTML;
}

function getBaseFilename(fullPath) {
    // Extract filename with extension using both Windows and Unix path separators
    const filenameWithExt = fullPath.split(/[\\/]/).pop();
    
    // Remove all extensions (everything after the first dot)
    const baseFilename = filenameWithExt.split('.')[0];
    
    return baseFilename;
}

function highlightMatchingOption(selectElementId, targetFullPath) {
    const selectElement = document.getElementById(selectElementId);
    if (!selectElement) {
        console.warn('Element not found:', selectElementId);
        return;
    }

    if (!targetFullPath || targetFullPath === '-') {
        selectElement.selectedIndex = 0;
        setSelectValue(selectElement, selectElement.value);   // redraws the skin's custom-select
        return;
    }

    // Use getBaseFilename to extract the short name (keeps original case)
    const targetBaseName = getBaseFilename(targetFullPath);
    const normalizePath = path => path.replace(/\\/g, '/');
    
    console.log(`Matching target: ${targetFullPath}`);
    console.log(`Base filename: ${targetBaseName}`);

    const isMaterialUI = selectElement.classList.contains('MuiSelect-nativeInput') || 
                        selectElement.closest('.MuiInputBase-root');

    const setValue = (element, value) => {
        if (isMaterialUI) {
            const hiddenInput = element.closest('.MuiInputBase-root')?.querySelector('input[type="hidden"]');
            if (hiddenInput) {
                hiddenInput.value = value;
                const event = new Event('change', { bubbles: true });
                hiddenInput.dispatchEvent(event);
            }
            
            const displayNode = element.closest('.MuiInputBase-root')?.querySelector('.MuiSelect-select');
            if (displayNode) {
                displayNode.textContent = value;
            }
        } else {
            for (let i = 0; i < element.options.length; i++) {
                if (element.options[i].value === value) {
                    element.selectedIndex = i;
                    element.dispatchEvent(new Event('change', { bubbles: true }));
                    break;
                }
            }
        }
    };

    // First try: match by base filename in option text
    if (!isMaterialUI) {
        for (let i = 0; i < selectElement.options.length; i++) {
            const optionBaseName = getBaseFilename(selectElement.options[i].text);
            if (optionBaseName === targetBaseName) {
                console.log(`Matched by base filename in text: ${selectElement.options[i].text}`);
                setValue(selectElement, selectElement.options[i].value);
                return;
            }
        }
    }

    // Second try: match by full path in option value
    const targetPath = normalizePath(targetFullPath);
    for (let i = 0; i < selectElement.options.length; i++) {
        const optionValue = normalizePath(selectElement.options[i].value);
        if (optionValue === targetPath) {
            console.log(`Matched by full path: ${optionValue}`);
            setValue(selectElement, selectElement.options[i].value);
            return;
        }
    }

    // Third try: match by base filename in option value
    for (let i = 0; i < selectElement.options.length; i++) {
        const optionBaseName = getBaseFilename(selectElement.options[i].value);
        if (optionBaseName === targetBaseName) {
            console.log(`Matched by base filename in value: ${selectElement.options[i].value}`);
            setValue(selectElement, selectElement.options[i].value);
            return;
        }
    }

    console.warn('No matching option found for:', targetFullPath);
}

function ListenForSlide() {
    const allRanges = document.querySelectorAll(".Slide");
    allRanges.forEach(wrap => {
        const range = wrap.querySelector(".range");
        const bubble = wrap.querySelector(".bubble");

        range.addEventListener("input", () => {
            setBubble(range, bubble);
        });
        setBubble(range, bubble);
    });
}

function setBubble(range, bubble) {
    const val = range.value;
    const min = range.min ? range.min : 0;
    const max = range.max ? range.max : 100;
  
    var mySlideName = range.id;
    if (mySlideName.endsWith("freq") || mySlideName.endsWith("Frequency")) {
        bubble.innerHTML = logScaleMapper(val);
    } else {
        bubble.innerHTML = val;
    }    
}

function showBubble(myObj) {
    var myBubble = document.getElementById(myObj.id + 'Bubble');
    setBubble(myObj, myBubble);
    myBubble.style.display = 'block';
}

function hideBubble(myObj) {
    document.getElementById(myObj.id + 'Bubble').style.display = 'none';
}

function improveMobileSliders() {
    const sliders = document.querySelectorAll('.range');
    
    sliders.forEach(slider => {
        // Prevent accidental changes on mobile
        slider.addEventListener('touchstart', function(e) {
            this.setAttribute('data-touch-start', this.value);
        });
        
        slider.addEventListener('touchend', function(e) {
            const startValue = this.getAttribute('data-touch-start');
            if (Math.abs(this.value - startValue) < 0.5) {
                // Small change, might be accidental
                console.log('Potential accidental touch on slider');
            }
        });
    });
}

// Simplified mobile initialization
function initializeTouchProtection() {
    if ('ontouchstart' in window) {
        console.log('Initializing touch protection for mobile');
        
        const ranges = document.querySelectorAll('.range');
        ranges.forEach(range => {
            range.addEventListener('touchstart', function(e) {
                // Small delay to prevent accidental changes
                setTimeout(() => {
                    this.focus();
                }, 100);
            });
        });
    }
}


// ── Kebab mini-menu ──────────────────────────────────────────────────────────

(function () {
    // One shared menu element, created once
    var _menu = null;
    var _dismissHandler = null;

    function getMenu() {
        if (_menu) return _menu;

        _menu = document.createElement('div');
        _menu.id = 'sqdsp-preset-menu';
        _menu.style.cssText = [
            'position:absolute',
            'z-index:9999',
            'background:var(--sq-bg, #2a2a2a)',
            'border:1px solid var(--sq-border, #555)',
            'border-radius:4px',
            'box-shadow:0 2px 8px rgba(0,0,0,0.45)',
            'min-width:130px',
            'padding:4px 0',
            'display:none',
            'font-size:0.9em',
        ].join(';');
        document.body.appendChild(_menu);
        return _menu;
    }

    function closeMenu() {
        var m = getMenu();
        m.style.display = 'none';
        if (_dismissHandler) {
            document.removeEventListener('pointerdown', _dismissHandler, true);
            _dismissHandler = null;
        }
    }

    function menuItem(label, cssClass, action) {
        var li = document.createElement('div');
        li.textContent = label;
        li.style.cssText = [
            'padding:7px 14px',
            'cursor:pointer',
            'white-space:nowrap',
            'color:' + (cssClass === 'danger'
                ? 'var(--sq-red,#e05555)'
                : 'var(--sq-text,#ddd)'),
        ].join(';');
        li.addEventListener('pointerover', function () {
            li.style.background = 'var(--sq-hover,#3a3a3a)';
        });
        li.addEventListener('pointerout', function () {
            li.style.background = '';
        });
        li.addEventListener('pointerdown', function (e) {
            e.stopPropagation();   // don't trigger the dismiss handler
            closeMenu();
            action();
        });
        return li;
    }

function openPresetMenu(anchorEl) {
    var presetName = document.getElementById('sel_Preset').value;
    var m = getMenu();
    m.innerHTML = '';

    // ── menu items ──────────────────────────────────────────────────────
    m.appendChild(menuItem('🗑 Delete preset', 'danger', function () {
        // --- REAL DELETE LOGIC (copied from old version) ---
        if (!presetName || presetName === '-') {
            DisplayAlert('Preset', 'No preset selected', 1500);
            return;
        }
        if (!confirm('Delete preset "' + presetName + '"?')) return;

        SqueezeDSPDeletePreset(presetName, function () {
            // Remove option from the select
            var sel = document.getElementById('sel_Preset');
            for (var i = sel.options.length - 1; i >= 0; i--) {
                if (sel.options[i].value === presetName) {
                    sel.remove(i);
                    break;
                }
            }
            sel.value = '-';
            DisplayAlert('Preset', 'Deleted', 2000);
        });
    }));

    // ── position the menu (your new smart positioning) ──────────────
    var rect = anchorEl.getBoundingClientRect();
    var scrollX = window.scrollX || document.documentElement.scrollLeft;
    var scrollY = window.scrollY || document.documentElement.scrollTop;

    m.style.display = 'block';
    var menuW = m.offsetWidth;
    var menuH = m.offsetHeight;

    var spaceBelow = window.innerHeight - rect.bottom;
    var top = (spaceBelow >= menuH || spaceBelow >= rect.top)
        ? rect.bottom + scrollY + 2
        : rect.top  + scrollY  - menuH - 2;

    var left = rect.left + scrollX;
    if (rect.left + menuW > window.innerWidth) {
        left = rect.right + scrollX - menuW;
    }
    if (left < scrollX + 5) {
        left = scrollX + 5;
    }

    m.style.top  = top + 'px';
    m.style.left = left + 'px';

    // Dismiss handler
    _dismissHandler = function (e) {
        if (!m.contains(e.target) && e.target !== anchorEl) {
            closeMenu();
        }
    };
    document.addEventListener('pointerdown', _dismissHandler, true);
}

    // Expose for the HTML onclick
    window.openPresetMenu = openPresetMenu;
})();