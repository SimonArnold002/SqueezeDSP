// Lets create the  SqueezeDSPData object
function getCurrentPlayer()
{
   return (playerid);
}

SqueezeDSPData = {
    Client: {},
    ClientName: "",
    Revision: 0
};

// what the current player can take, from readclientSettings (see LocalSetupOutput)
var SqueezeDSPPlayer = null;

function InitialiseData()

    {
    return {
        Bypass: 1,
        OutputFormat: "FLAC",   // or "PCM": 24-bit WAV with its header, for a player that reads one
        Upsample: "off",        // or "on": soxr in ffmpeg, in float, before the DSP (Upsample.pm)
        UpsamplePrecision: 28,  // soxr bits: 20, 24, 28, 33
        UpsampleSteep: 0,       // 1: soxr's Chebyshev passband
        UpsamplePassband: 0.99, // 0.80-0.995 of the track's Nyquist, a fixed target at most 0.95; 0: Auto, soxr's own
        UpsamplePhase: "linear", // or "intermediate", "minimum": sox's rate, with headroom (Upsample.pm)
        UpsampleTarget: "family", // or "fixed": every track, DSD included, to the player's top rate
        UpsampleMax: 0,         // 0: the player's top rate; or 768000, 384000, 192000, 96000 below it
        DSDCutoff: 30000,       // a DSF on our engine (0.3.13): its low-pass, Hz; 24000, 30000, 50000, or 0 for none
        DSDGain: 0,             // ... and its gain, dB: 0 or 6 (DSD plays 6 dB under PCM)
        Preamp: 0,
        Balance: 0,
        Width: 0,
        Delay: { delay: 0 },
        Loudness: {
            enabled: 0,
            listening_level: 85
        },
        Filters: [],
        FIRWavFile: "-",
        Last_preset: "",
        Preset: "None",
		FIRStrength: 100,
		Crossfeed: "off",
		ReplayGain: {
			enabled: 0,
			mode:         3,   // 1=track only, 2=album only, 3=smart gain (default)
			fixed_gain: -6.0,
			spotify_gain: -4.0,
		},
    };
}

function InitialiseSqueezeDSPData()
{
    if (typeof SqueezeDSPData === 'undefined') {
        SqueezeDSPData = {
            ClientName: "",
            Revision: 0
        };
        return;
    }
    SqueezeDSPData.Client = InitialiseData();
    // Ensure top-level structure exists
    SqueezeDSPData.Client = SqueezeDSPData.Client || {};
    SqueezeDSPData.ClientName = SqueezeDSPData.ClientName || "";
    SqueezeDSPData.Revision = SqueezeDSPData.Revision || 0;

}

function deepMerge(target, source) {
    const result = Object.assign({}, target);
    for (const key of Object.keys(source)) {
        if (source[key] !== null &&
            typeof source[key] === 'object' &&
            !Array.isArray(source[key]) &&
            typeof target[key] === 'object' &&
            target[key] !== null) {
            result[key] = deepMerge(target[key], source[key]);
        } else if (source[key] !== undefined) {
            result[key] = source[key];
        }
    }
    return result;
}


function transformLegacyFilters(data) {
	if (!data || !data.Client) return data;

    const client = data.Client;
    if (!client.Filters) {
        client.Filters = [];
    }

    // Helper functions
    const toBoolean = val => String(val) === "1";
    const toNumber = val => parseFloat(val) || 0;

    // Process EQBand_* filters (Peaking filters)
    const eqBandKeys = Object.keys(client).filter(key => key.startsWith('EQBand_'));

    // Determine conversion count
    const eqBandsCount = client.EQBands ? parseInt(client.EQBands) : 0;
    const conversionCount = Math.min(eqBandsCount, eqBandKeys.length);

// Convert only the required bands
    for (let i = 0; i < conversionCount; i++) {
        const key = `EQBand_${i}`;
        if (client[key]) {
            const filter = client[key];
            client.Filters.push({
                FilterType: "peak",
                Frequency: toNumber(filter.freq),
                Gain: toNumber(filter.gain),
                SlopeType: "Q",
                Slope: toNumber(filter.q)
            });
        }
}

// Delete ALL EQBand_* keys and EQBands
eqBandKeys.forEach(key => delete client[key]);
delete client.EQBands;

    // Process Lowshelf
    if (client.Lowshelf) {
        const ls = client.Lowshelf;
        if (toBoolean(ls.enabled)) {
            client.Filters.push({
                FilterType: "lowshelf",
                Frequency: toNumber(ls.freq),
                Gain: toNumber(ls.gain),
                SlopeType: "slope",
                Slope: toNumber(ls.slope)
            });
        }
        delete client.Lowshelf;
    }

    // Process Highshelf
    if (client.Highshelf) {
        const hs = client.Highshelf;
        if (toBoolean(hs.enabled)) {
            client.Filters.push({
                FilterType: "highshelf",
                Frequency: toNumber(hs.freq),
                Gain: toNumber(hs.gain),
                SlopeType: "slope",
                Slope: toNumber(hs.slope)
            });
        }
        delete client.Highshelf;
    }

    // Process Lowpass
    if (client.Lowpass) {
        const lp = client.Lowpass;
        if (toBoolean(lp.enabled)) {
            client.Filters.push({
                FilterType: "lowpass",
                Frequency: toNumber(lp.freq),
                Gain: 0,
                SlopeType: "Q",
                Slope: toNumber(lp.q)
            });
        }
        delete client.Lowpass;
    }

    // Process Highpass
    if (client.Highpass) {
        const hp = client.Highpass;
        if (toBoolean(hp.enabled)) {
            client.Filters.push({
                FilterType: "highpass",
                Frequency: toNumber(hp.freq),
                Gain: 0,
                SlopeType: "Q",
                Slope: toNumber(hp.q)
            });
        }
        delete client.Highpass;
    }

    // Remove deprecated fields
    delete client.EQBands;
    
    return data;
}



function SqueezeDSPGetList(callback)
{
	// calls plugin filtersQuery
	new Ajax.Request('/jsonrpc.js', {
		method: 'post',
		asynchronous: true,
		postBody: Object.toJSON({
			id: 1, 
			method: 'slim.request', 
			params: [
				getCurrentPlayer(), 
				[
					'squeezedsp.filters'
				]
			]
		}),

		onFailure: function() { alert('Failed'); },

		onSuccess: function(response) {
			// debugger;
		var data = response.responseText.evalJSON(true);

		callback(data);

		}
	});
}


function SqueezeDSPLogSummary(callback)
{
	//alert ('Getting Settings');
	// calls plugin currentQuery
	new Ajax.Request('/jsonrpc.js', {
		method: 'post',
		asynchronous: true,
		//asynchronous: false,
		postBody: Object.toJSON({
			id: 1, 
			method: 'slim.request', 
			params: [
				getCurrentPlayer(), 
				[
					'squeezedsp.logsummary'
				]
			]
		}),

		onFailure: function() { alert('Failed'); },

		onSuccess: function(response) {
			// debugger;
		var data = response.responseText.evalJSON();
		callback(data);
		
		}
	});
}



function SqueezeDSPSelectPreset()
{
	// Save this value (async)
	// calls plugin setvalCommand - should drop through to loading preset
	var myProperty='Preset';
	var myVal = 'Joxy.preset.conf';
	new Ajax.Request('/jsonrpc.js', {
		method: 'post',
		asynchronous: true,
		postBody: Object.toJSON({
			id: 1, 
			method: 'slim.request', 
			params: [
				getCurrentPlayer(), 
				[
					'squeezedsp.setval',
					'key:'+myProperty,
					'val:'+myVal
				]
				]
			}),
			onFailure: function() { alert('Failed') },
			onSuccess: function(response) { 	// debugger;
			var data = response.responseText.evalJSON();
			SqueezeDSPGetSettings(LocalUpdateSettings);
			}
		});
	}

function SqueezeDSPSelectValue(myProperty, myVal, callback)
{
	// calls plugin setvalCommand - should drop through to setpref command
	// Save this value (async)

	//alert (myProperty);
	new Ajax.Request('/jsonrpc.js', {
		method: 'post',
		asynchronous: true,
		postBody: Object.toJSON({
			id: 1, 
			method: 'slim.request', 
			params: [
				getCurrentPlayer(), 
				[
					'squeezedsp.setval',
					'key:'+myProperty,
					'val:'+myVal
				]
				]
			}),
			onFailure: function() { alert('Failed') },
			onSuccess: function(response) { 	// debugger;
			var data = response.responseText.evalJSON();
			if(typeof callback !== 'undefined'){
					SqueezeDSPGetSettings(callback);
				};
			//SqueezeDSPGetSettings(LocalUpdateSettings);
			}
		});
	}
function SqueezeDSPSavePreset(myVal, callback)
{
	// calls plugin saveasCommand
	// Save this value (async)
	new Ajax.Request('/jsonrpc.js', {
		method: 'post',
		asynchronous: true,
		postBody: Object.toJSON({
			id: 1, 
			method: 'slim.request', 
			params: [
				getCurrentPlayer(), 
				[
					'squeezedsp.saveas',
					'preset:' + myVal,
				],
			]

		}),
		onFailure: function() { alert('Failed'); },

		onSuccess: function(response) {
			// debugger;
		var data = response.responseText.evalJSON();
				
		callback();
		}	});
}

function SqueezeDSPDeletePreset(presetName, callback) {
    if (!presetName || presetName === '-') return;
    new Ajax.Request('/jsonrpc.js', {
        method: 'post',
        asynchronous: true,
        postBody: Object.toJSON({
            id: 1,
            method: 'slim.request',
            params: [
                getCurrentPlayer(),
                [
                    'squeezedsp.deletepreset',
                    'preset:' + presetName,
                ],
            ],
        }),
        onFailure: function () { alert('Delete failed'); },
        onSuccess: function (response) {
            var data = response.responseText.evalJSON();
            if (callback) callback();
        },
    });
}


function SqueezeDSPSaveEQBand(myBand, myFreq, myGain, myQ)
{
				//calls plugin seteqCommand
				new Ajax.Request('/jsonrpc.js', {
					method: 'post',
					asynchronous: true,
					postBody: Object.toJSON({
						id: 1, 
						method: 'slim.request', 
						params: [
							getCurrentPlayer(), 
							[
								'squeezedsp.seteq',
								'band:'+myBand,
								'freq:'+myFreq,
								'gain:'+myGain,
								'q:'+myQ
							]
						]
					}),
					onFailure: function() { alert('Failed'); },
					onSuccess: function(response) {
					// debugger;
						var data = response.responseText.evalJSON();
					}
				});
}

// Fetch current settings from server
// Modified processing function
// Fetch current settings from server
function SqueezeDSPFetchCurrentSettings(callback) {
    new Ajax.Request('/jsonrpc.js', {
        method: 'post',
        postBody: Object.toJSON({
            id: 1,
            method: 'slim.request',
            params: [getCurrentPlayer(), ['squeezedsp.readclientSettings']]
        }),
        onSuccess: (response) => {
            const data = response.responseText.evalJSON();
            const rawJson = data.result.json;

            // What this player can take (kept out of SqueezeDSPData, which saveall writes back):
            // the DSP at all, and PCM as WAV with its header. An older server sends neither.
            SqueezeDSPPlayer = {
                dspOk: Number(data.result.dsp_ok) !== 0,
                wavOk: Number(data.result.wav_ok) === 1,
                // Upsample: available here (an ffmpeg with soxr, a known max), why not, the two targets
                upOk: Number(data.result.up_ok) === 1,
                upWhy: data.result.up_why || '',
                upTargets: data.result.up_targets || '',
                // and the fixed target, the player's top rate (an older server sends none)
                upFixed: data.result.up_fixed || '',
                // the player's top rate with no max rate chosen: with FLAC out, with WAV out
                upLimits: data.result.up_limits || '',
                upFfmpeg: data.result.up_ffmpeg || '',
                // the sox the intermediate and minimum phases need
                upSox: data.result.up_sox || '',
                // a reduced stream (MP3, OPS, OGG), and the Bitrate Limiting an MP3 is at (0: an app's 320 kbps)
                outReduced: data.result.out_reduced || '',
                outKbps: Number(data.result.out_kbps) || 0
            };

            try {
                // Start with a fully-defaulted structure
                const defaults = {
                    Client: InitialiseData()
                };

                // Parse server data (may be sparse or empty for new players)
                let serverData = {};
                try {
                    serverData = rawJson ? JSON.parse(rawJson) : {};
                } catch (e) {
                    console.warn("Could not parse server JSON, treating as fresh player:", e);
                }

                // Deep merge server data over defaults
                SqueezeDSPData = deepMerge(defaults, serverData);
                SqueezeDSPData.ClientName = data.result.clientName;

                SqueezeDSPData.Revision = data.result.revision || 1;
				const isFreshPlayer = data.result.fresh_player === 1;
				delete SqueezeDSPData.fresh_player; // belt-and-braces in case it leaked into serverData


                // Transform any legacy filter format
                SqueezeDSPData = transformLegacyFilters(SqueezeDSPData);

                // If fresh player: defaults are now in place, persist them immediately
                if (isFreshPlayer) {
                    console.log("Fresh player detected — saving default settings");
                    SqueezeDSPSaveAll(function(ok) {
                        if (!ok) console.warn("Failed to save defaults for fresh player");
                    });
                }
				console.log("Post-merge SqueezeDSPData:", JSON.stringify(SqueezeDSPData, null, 2));
				initializePEQGraph();
                if (callback) callback();

            } catch (e) {
                console.error("JSON parsing error:", e);
            }
        }
    });
}


function SqueezeDSPFetchPresetSettings(presetFilePath, callback) {
    // Only proceed if this is not a programmatic change
    const cleanedPresetFilePath = presetFilePath.replace(/\\/g, '/');
    
    // Better callback handling with validation
    let callbacks = [];
    if (callback) {
        if (Array.isArray(callback)) {
            callbacks = callback.filter(cb => typeof cb === 'function');
        } else if (typeof callback === 'function') {
            callbacks = [callback];
        } else {
            console.warn('SqueezeDSPFetchPresetSettings: callback is not a function or array of functions', callback);
        }
    }
    
    new Ajax.Request('/jsonrpc.js', {
        method: 'post',
        postBody: Object.toJSON({
            id: 1, 
            method: 'slim.request', 
            params: [getCurrentPlayer(), ['squeezedsp.readpresetSettings', 'presetFileName:' + cleanedPresetFilePath]]
        }),
        onSuccess: (response) => {
            const data = response.responseText.evalJSON();
            const rawJson = data.result.json;
            
            try {
                LocalClearSettings();
                SqueezeDSPData = JSON.parse(rawJson);
                SqueezeDSPData.ClientName = data.result.clientName;
                SqueezeDSPData.Revision = data.result.revision || 1;
                SqueezeDSPData = transformLegacyFilters(SqueezeDSPData);
                
                // Execute callbacks with better error handling
                if (callbacks.length > 0) {
                    callbacks.forEach(cb => {
                        try {
                            // Check if it's still a function before calling
                            if (typeof cb === 'function') {
                                cb();
                            } else {
                                console.warn('SqueezeDSPFetchPresetSettings: callback is no longer a function', cb);
                            }
                        } catch (e) {
                            console.error("Error executing callback in SqueezeDSPFetchPresetSettings:", e);
                        }
                    });
                }
            } catch (e) {
                console.error("JSON parsing error in SqueezeDSPFetchPresetSettings:", e);
            }
        },
        onFailure: (response) => {
            console.error('Failed to fetch preset settings', response.status, response.statusText);
        }
    });
}

function SqueezeDSPSaveAll(callback) {

 	
    new Ajax.Request('/jsonrpc.js', {
        method: 'post',
        postBody: Object.toJSON({
            id: 1,
            method: 'slim.request',
            params: [
                getCurrentPlayer(),
                [
                    'squeezedsp.saveall',
                    'val:' + JSON.stringify(SqueezeDSPData)  // Send the JSON string
                ]
            ]
        }),
		onSuccess: (response) => {
            // Just check for done status, no result content
            const data = response.responseText.evalJSON();
            if (data.result && data.result._done) {
                if (callback) callback(true);
            } else {
                console.error('Save failed:', data);
                if (callback) callback(false, data.error);
            }
            reStyleElement('btn_Apply', 'button-amber', 'button-blue');
        },
        onFailure: (response) => {
            console.error('Save failed', response.status, response.statusText);
            if (callback) callback(false, response.statusText);
            reStyleElement('btn_Apply', 'button-amber', 'button-red');
        }
    });
}


function importWavFile(file, callbackLog = console.log, callbackRefresh = "") {
    if (!confirm('Import Filter Impulse Response file:\n' + file.name)) {
        return;
    }
    
    callbackLog('Importing: ' + file.name);
   
    const reader = new FileReader();
    reader.onload = function(e) {
        const base64Data = e.target.result.split(',')[1];
        
        new Ajax.Request('/jsonrpc.js', {
            method: 'post',
            postBody: Object.toJSON({
                id: 1,
                method: 'slim.request',
                params: [
                    getCurrentPlayer(),
                    [
                        'squeezedsp.importwav',
                        '_p0:' + file.name,
                        '_p1:' + base64Data
                    ]
                ]
            }),
            onSuccess: (response) => {
                const json = response.responseText.evalJSON();
                if (json?.result?._success) {
                    callbackLog('Imported: ' + file.name);
					if (callbackRefresh) callbackRefresh();
                } else {
                    callbackLog('Failed to import: ' + file.name);
                }
            },
            onFailure: () => {
                callbackLog('Failed to import: ' + file.name);
            }
        });
    };
    reader.onerror = () => {
        callbackLog('Error reading file: ' + file.name);
    };
    reader.readAsDataURL(file);
}

function SqueezeDSPClearLog(callback) {
    // calls plugin clearlogCommand
    new Ajax.Request('/jsonrpc.js', {
        method: 'post',
        asynchronous: true,
        postBody: Object.toJSON({
            id: 1, 
            method: 'slim.request', 
            params: [
                getCurrentPlayer(), 
                [
                    'squeezedsp.clearlog'
                ]
            ]
        }),

        onFailure: function(response) { 
            console.error('Failed to clear log:', response.statusText);
            if (typeof callback === 'function') {
                callback(false, 'Failed to clear log: ' + response.statusText);
            }
        },

        onSuccess: function(response) {
            // debugger;
            var data = response.responseText.evalJSON(true);
            
            // Check if we got an error from the server
            if (data.error) {
                console.error('Server error clearing log:', data.error);
                if (typeof callback === 'function') {
                    callback(false, 'Server error: ' + data.error.message);
                }
                return;
            }
            
            // Success case - check the result structure
            if (data.result && data.result._success == 1) {
                console.log('Log cleared successfully');
                if (typeof callback === 'function') {
                    callback(true, data.result._message || 'Log cleared successfully');
                }
            } else {
                console.error('Log clear failed:', data.result ? data.result._message : 'Unknown error');
                if (typeof callback === 'function') {
                    callback(false, data.result ? data.result._message : 'Failed to clear log');
                }
            }
        }
    });
}
